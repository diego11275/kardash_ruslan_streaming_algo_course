// lsm.go
package lsm // Пакет lsm реализует LSM-дерево (Log-Structured Merge-tree)

import (
	"bytes"           // Сравнение байтовых срезов
	"container/heap"  // Куча для эффективного слияния итераторов
	"errors"          // Создание ошибок
	"fmt"             // Форматированный вывод
	"io"              // Интерфейсы ввода-вывода
	"os"              // Взаимодействие с ОС
	"path/filepath"   // Работа с путями файлов
	"sort"            // Сортировка строк
	"sync"            // Примитивы синхронизации

	"kvschool/internal/bloom"    // Bloom-фильтр
	"kvschool/internal/skiplist" // Memtable (skip‑list)
	"kvschool/internal/sstable"  // SSTable
	"kvschool/internal/wal"      // Write‑Ahead Log
)

var ErrNotFound = errors.New("lsm: key not found")

type Options struct { // Конфигурация движка
	Dir                    string  // Путь к директории хранения
	MemtableFlushThreshold int     // Порог размера memtable для сброса на диск (байт)
	SyncWrites             bool    // Синхронизировать WAL после каждой записи
	L0CompactThreshold     int     // Количество L0‑файлов для запуска компакшена (по умолчанию 4)
	BloomFalsePositiveRate float64 // Целевая вероятность ложного срабатывания bloom-фильтра
}

type Engine struct { // Основная структура LSM-движка
	opts        Options          // Конфигурация
	mu          sync.Mutex       // Мьютекс для потокобезопасного доступа
	mem         *skiplist.SkipList // Активная memtable
	memSize     int              // Приблизительный размер memtable (сумма длин ключей и значений)
	walWriter   *wal.Writer      // Писатель WAL
	walFile     *os.File         // Файл WAL
	sstables    []*sstable.Reader // Читатели L0 SSTable (от новых к старым)
	sstFiles    []*os.File       // Открытые файлы L0
	sstBloom    []*bloom.Filter  // Bloom-фильтры для L0 (могут быть nil)
	l1          *sstable.Reader  // Читатель L1 (nil если нет)
	l1File      *os.File         // Файл L1
	l1Bloom     *bloom.Filter    // Bloom-фильтр для L1 (может быть nil)
	compactTrigger chan struct{} // Канал сигнала компакшена (буфер 1)
	compactDone    chan struct{} // Канал для остановки воркера компакшена
	closeWG        sync.WaitGroup // Ожидание завершения фонового воркера
	closed         bool          // Флаг, что движок закрыт
}

// Open открывает или создаёт LSM-хранилище.
func Open(opts Options) (*Engine, error) {
	if err := os.MkdirAll(opts.Dir, 0755); err != nil { return nil, fmt.Errorf("lsm: create dir: %w", err) }
	if opts.L0CompactThreshold <= 0 { opts.L0CompactThreshold = 4 }
	if opts.BloomFalsePositiveRate <= 0 || opts.BloomFalsePositiveRate >= 1 { opts.BloomFalsePositiveRate = 0.01 } // По умолчанию 1%

	e := &Engine{ // Инициализация движка
		opts:           opts,
		mem:            skiplist.New(0),        // Пустая memtable
		compactTrigger: make(chan struct{}, 1), // Канал с буфером 1
		compactDone:    make(chan struct{}),    // Канал завершения воркера
	}

	// Загружаем существующие SSTable
	sstFiles, err := filepath.Glob(filepath.Join(opts.Dir, "*.sst"))
	if err != nil { return nil, err }
	sort.Strings(sstFiles) // От старых к новым

	// Загружаем L1
	l1Path := filepath.Join(opts.Dir, "level1.sst")
	if _, err := os.Stat(l1Path); err == nil {
		f, err := os.Open(l1Path)
		if err != nil { return nil, fmt.Errorf("lsm: open L1: %w", err) }
		fi, err := f.Stat() // Размер файла
		if err != nil { f.Close(); return nil, err }
		r, err := sstable.NewReader(f, fi.Size()) // Читатель
		if err != nil { f.Close(); return nil, fmt.Errorf("lsm: read L1: %w", err) }
		e.l1 = r
		e.l1File = f
		e.l1Bloom = e.buildFilter(r) // Восстановить bloom-фильтр
	}

	// Загружаем L0 (от новых к старым)
	for i := len(sstFiles) - 1; i >= 0; i-- {
		fname := sstFiles[i]
		if filepath.Base(fname) == "level1.sst" { continue }
		rd, err := os.Open(fname)
		if err != nil { return nil, fmt.Errorf("lsm: open sst %s: %w", fname, err) }
		fi, err := rd.Stat()
		if err != nil { rd.Close(); return nil, err }
		r, err := sstable.NewReader(rd, fi.Size())
		if err != nil { rd.Close(); return nil, fmt.Errorf("lsm: read sst %s: %w", fname, err) }
		e.sstables = append(e.sstables, r)
		e.sstFiles = append(e.sstFiles, rd)
		e.sstBloom = append(e.sstBloom, e.buildFilter(r)) // Фильтр сразу
	}

	// WAL и восстановление memtable
	walPath := filepath.Join(opts.Dir, "wal.log")
	walFile, err := os.OpenFile(walPath, os.O_RDWR|os.O_CREATE|os.O_APPEND, 0644)
	if err != nil { return nil, fmt.Errorf("lsm: open WAL: %w", err) }
	if err := e.recoverFromWAL(walFile); err != nil {
		walFile.Close()
		return nil, fmt.Errorf("lsm: recover WAL: %w", err)
	}
	if _, err := walFile.Seek(0, io.SeekEnd); err != nil {
		walFile.Close()
		return nil, err
	}
	e.walFile = walFile
	e.walWriter = wal.NewWriter(walFile)

	e.closeWG.Add(1)
	go e.compactionWorker() // Фоновый компакшен
	return e, nil
}

// recoverFromWAL восстанавливает memtable из записей WAL.
func (e *Engine) recoverFromWAL(f *os.File) error {
	if _, err := f.Seek(0, io.SeekStart); err != nil { return err } // В начало файла
	reader := wal.NewReader(f)
	for {
		rec, ok, err := reader.Next()
		if err != nil { return err }
		if !ok { break }
		switch rec.Type {
		case wal.OpPut:
			if err := e.mem.Put(rec.Key, rec.Value); err != nil { return err }
			e.memSize += len(rec.Key) + len(rec.Value)
		case wal.OpDelete:
			if err := e.mem.Put(rec.Key, nil); err != nil { return err }
			e.memSize += len(rec.Key)
		}
	}
	return nil
}

// flushMemtable сбрасывает memtable в новый SSTable уровня 0 и обрезает WAL.
func (e *Engine) flushMemtable() error {
	nextNum := len(e.sstables)
	sstName := filepath.Join(e.opts.Dir, fmt.Sprintf("%06d.sst", nextNum))
	f, err := os.Create(sstName)
	if err != nil { return err }
	writer := sstable.NewWriter(f)

	iter, err := e.mem.Scan(nil, nil) // Итератор по всей memtable
	if err != nil { f.Close(); return err }
	defer iter.Close()

	var keys [][]byte // Ключи для bloom-фильтра
	for {
		k, v, ok, err := iter.Next()
		if err != nil { return err }
		if !ok { break }
		keys = append(keys, k)
		if v == nil {
			if err := writer.Delete(k); err != nil { return err }
		} else {
			if err := writer.Put(k, v); err != nil { return err }
		}
	}

	size, err := writer.Finish() // Завершить запись, получить размер данных
	if err != nil { f.Close(); return err }
	if err := f.Close(); err != nil { return err }

	// Обрезка WAL
	if e.walWriter != nil { if err := e.walWriter.Close(); err != nil { return err } } // Закрыть писатель
	if e.opts.SyncWrites { if err := e.walFile.Sync(); err != nil { return err } }      // Синхронизировать WAL
	if err := e.walFile.Truncate(0); err != nil { return err }                          // Обрезать до нуля
	if _, err := e.walFile.Seek(0, io.SeekStart); err != nil { return err }            // В начало файла
	e.walWriter = wal.NewWriter(e.walFile)                                               // Новый писатель

	rd, err := os.Open(sstName) // Открыть новый SSTable для чтения
	if err != nil { return err }
	r, err := sstable.NewReader(rd, size) // Читатель
	if err != nil { rd.Close(); return err }

	var bf *bloom.Filter
	if len(keys) > 0 {
		n := uint64(len(keys))
		m, k, err := bloom.OptimalParams(n, e.opts.BloomFalsePositiveRate)
		if err == nil {
			bf = bloom.New(m, k)
			for _, key := range keys { _ = bf.Add(key) }
		}
	}

	// Вставить новый SSTable в начало списков L0
	e.sstables = append([]*sstable.Reader{r}, e.sstables...)
	e.sstFiles = append([]*os.File{rd}, e.sstFiles...)
	e.sstBloom = append([]*bloom.Filter{bf}, e.sstBloom...)

	e.mem = skiplist.New(0) // Новая пустая memtable
	e.memSize = 0
	return nil
}

// compact сливает все L0 и L1 в новый L1, удаляет старые файлы.
func (e *Engine) compact() error {
	if len(e.sstables) == 0 && e.l1 == nil { return nil }

	var iterators []kvIterator
	for _, r := range e.sstables {
		it, err := r.Iterator(nil, nil)
		if err != nil { return err }
		iterators = append(iterators, &sstableIterAdapter{it})
	}
	if e.l1 != nil {
		it, err := e.l1.Iterator(nil, nil)
		if err != nil { return err }
		iterators = append(iterators, &sstableIterAdapter{it})
	}

	mergeIt, err := newMergeHeapIterator(iterators) // Куча для слияния
	if err != nil { return err }
	defer mergeIt.Close()

	tmpPath := filepath.Join(e.opts.Dir, "level1.sst.tmp")
	f, err := os.Create(tmpPath) // Временный файл
	if err != nil { return err }
	writer := sstable.NewWriter(f)

	var liveKeys [][]byte // Ключи для bloom-фильтра L1
	for {
		k, v, ok, err := mergeIt.Next()
		if err != nil { f.Close(); os.Remove(tmpPath); return err }
		if !ok { break }
		if err := writer.Put(k, v); err != nil { f.Close(); os.Remove(tmpPath); return err }
		liveKeys = append(liveKeys, k) // После слияния дубликатов нет, все ключи живые
	}

	size, err := writer.Finish()
	if err != nil { f.Close(); os.Remove(tmpPath); return err }
	if err := f.Close(); err != nil { os.Remove(tmpPath); return err }

	l1Path := filepath.Join(e.opts.Dir, "level1.sst")
	if err := os.Rename(tmpPath, l1Path); err != nil { os.Remove(tmpPath); return err } // Атомарная замена

	// Удаляем старые L0
	for _, f := range e.sstFiles { f.Close(); os.Remove(f.Name()) }
	e.sstables = nil
	e.sstFiles = nil
	e.sstBloom = nil

	// Закрываем старый L1
	if e.l1File != nil { e.l1File.Close(); e.l1File = nil }
	e.l1 = nil
	e.l1Bloom = nil

	// Открываем новый L1
	rd, err := os.Open(l1Path)
	if err != nil { return err }
	r, err := sstable.NewReader(rd, size)
	if err != nil { rd.Close(); return err }
	e.l1 = r
	e.l1File = rd

	if len(liveKeys) > 0 {
		n := uint64(len(liveKeys))
		m, k, err := bloom.OptimalParams(n, e.opts.BloomFalsePositiveRate)
		if err == nil {
			bf := bloom.New(m, k)
			for _, key := range liveKeys { _ = bf.Add(key) }
			e.l1Bloom = bf
		}
	}
	return nil
}

// maybeCompact отправляет сигнал фоновому воркеру, если порог превышен.
func (e *Engine) maybeCompact() {
	if len(e.sstables) >= e.opts.L0CompactThreshold {
		select {
		case e.compactTrigger <- struct{}{}: // Неблокирующий сигнал
		default: // Уже ожидает
		}
	}
}

// compactionWorker – фоновый процесс компакшена.
func (e *Engine) compactionWorker() {
	defer e.closeWG.Done()
	for {
		select {
		case <-e.compactTrigger:
			e.mu.Lock()
			if !e.closed && len(e.sstables) >= e.opts.L0CompactThreshold {
				_ = e.compact() // Ошибки игнорируются для простоты
			}
			e.mu.Unlock()
		case <-e.compactDone:
			return
		}
	}
}

// applyWrite – общая логика записи (Put / Delete).
func (e *Engine) applyWrite(op wal.OpType, key, value []byte) error {
	if key == nil { return fmt.Errorf("lsm: key cannot be nil") }
	rec := wal.Record{Type: op, Key: key, Value: value}
	if err := e.walWriter.Append(rec); err != nil { return err }                    // WAL
	if e.opts.SyncWrites { if err := e.walWriter.Flush(); err != nil { return err } } // Синхронизация WAL

	if err := e.mem.Put(key, value); err != nil { return err } // Memtable
	if op == wal.OpPut { e.memSize += len(key) + len(value) } else { e.memSize += len(key) }

	if e.memSize >= e.opts.MemtableFlushThreshold {
		if err := e.flushMemtable(); err != nil { return fmt.Errorf("lsm: flush: %w", err) }
		e.maybeCompact()
	}
	return nil
}

// Put вставляет или обновляет значение.
func (e *Engine) Put(key, value []byte) error {
	e.mu.Lock(); defer e.mu.Unlock()
	return e.applyWrite(wal.OpPut, key, value)
}

// Delete помечает ключ как удалённый (tombstone).
func (e *Engine) Delete(key []byte) error {
	e.mu.Lock(); defer e.mu.Unlock()
	return e.applyWrite(wal.OpDelete, key, nil)
}

// Get ищет ключ (memtable → L0 с bloom → L1 с bloom).
func (e *Engine) Get(key []byte) ([]byte, error) {
	e.mu.Lock(); defer e.mu.Unlock()

	// Memtable
	if val, err := e.mem.Get(key); err == nil {
		if val == nil { return nil, ErrNotFound }
		return val, nil
	}
	// L0
	for i, r := range e.sstables {
		if bf := e.sstBloom[i]; bf != nil { // Если фильтр есть
			if maybe, err := bf.MayContain(key); err != nil { return nil, err } else if !maybe { continue }
		}
		v, found, rt, err := r.Lookup(key)
		if err != nil { return nil, err }
		if found {
			if rt == sstable.RecordTypeDelete { return nil, ErrNotFound }
			return v, nil
		}
	}
	// L1
	if e.l1 != nil {
		if bf := e.l1Bloom; bf != nil {
			if maybe, err := bf.MayContain(key); err != nil { return nil, err } else if !maybe { return nil, ErrNotFound }
		}
		v, found, rt, err := e.l1.Lookup(key)
		if err != nil { return nil, err }
		if found {
			if rt == sstable.RecordTypeDelete { return nil, ErrNotFound }
			return v, nil
		}
	}
	return nil, ErrNotFound
}

// MemSize возвращает текущий размер memtable.
func (e *Engine) MemSize() int {
	e.mu.Lock(); defer e.mu.Unlock()
	return e.memSize
}

// ForceFlush принудительно сбрасывает memtable на диск.
func (e *Engine) ForceFlush() error {
	e.mu.Lock(); defer e.mu.Unlock()
	if e.memSize > 0 { return e.flushMemtable() }
	return nil
}

// buildFilter строит bloom-фильтр по всем ключам SSTable (nil, если таблица пуста).
func (e *Engine) buildFilter(r *sstable.Reader) *bloom.Filter {
	it, _ := r.Iterator(nil, nil) // Итератор по всей таблице
	defer it.Close()
	var keys [][]byte
	for k, _, ok, _ := it.Next(); ok; k, _, ok, _ = it.Next() { keys = append(keys, k) }
	if len(keys) == 0 { return nil } // Пустая таблица
	m, k, err := bloom.OptimalParams(uint64(len(keys)), e.opts.BloomFalsePositiveRate)
	if err != nil { return nil }
	bf := bloom.New(m, k)
	for _, key := range keys { bf.Add(key) }
	return bf
}

// Iterator – публичный итератор для Scan (основан на куче).
type Iterator struct {
	mi *mergeHeapIterator
}
func (it *Iterator) Next() ([]byte, []byte, bool, error) { return it.mi.Next() }
func (it *Iterator) Close() error { return it.mi.Close() }

// Scan возвращает итератор по диапазону [start, end).
func (e *Engine) Scan(start, end []byte) (*Iterator, error) {
	e.mu.Lock(); defer e.mu.Unlock()
	iterators := make([]kvIterator, 0, len(e.sstables)+2)
	memIter, err := e.mem.Scan(start, end) // Memtable
	if err != nil { return nil, err }
	iterators = append(iterators, &memtableIterAdapter{memIter})
	for _, r := range e.sstables { // L0
		sstIter, err := r.Iterator(start, end)
		if err != nil { return nil, err }
		iterators = append(iterators, &sstableIterAdapter{sstIter})
	}
	if e.l1 != nil { // L1
		l1Iter, err := e.l1.Iterator(start, end)
		if err != nil { return nil, err }
		iterators = append(iterators, &sstableIterAdapter{l1Iter})
	}
	mergeIt, err := newMergeHeapIterator(iterators) // Куча для слияния
	if err != nil { return nil, err }
	return &Iterator{mi: mergeIt}, nil
}

// Close корректно останавливает движок.
func (e *Engine) Close() error {
	e.mu.Lock()
	e.closed = true
	e.mu.Unlock()
	close(e.compactDone)  // Остановка воркера
	e.closeWG.Wait()      // Ожидание завершения
	e.mu.Lock()
	defer e.mu.Unlock()
	if e.walWriter != nil { e.walWriter.Close() }
	if e.walFile != nil { e.walFile.Close() }
	for _, f := range e.sstFiles { f.Close() } // Все L0
	if e.l1File != nil { e.l1File.Close() }     // L1
	return nil
}

// --------------------------------------------------------------------
// Интерфейс итератора и адаптеры
// --------------------------------------------------------------------

type kvIterator interface {
	Next() ([]byte, []byte, bool, error)
	Close() error
}

type memtableIterAdapter struct {
	iter skiplist.Iterator
}
func (a *memtableIterAdapter) Next() ([]byte, []byte, bool, error) { return a.iter.Next() }
func (a *memtableIterAdapter) Close() error { return a.iter.Close() }

type sstableIterAdapter struct {
	iter *sstable.Iter
}
func (a *sstableIterAdapter) Next() ([]byte, []byte, bool, error) { return a.iter.Next() }
func (a *sstableIterAdapter) Close() error { return a.iter.Close() }

// --------------------------------------------------------------------
// mergeHeapIterator – слияние с кучей (O(log K) на ключ)
// --------------------------------------------------------------------

type heapItem struct {
	iter  kvIterator
	key   []byte
	value []byte
	index int // индекс в куче
}

type priorityQueue []*heapItem

func (pq priorityQueue) Len() int { return len(pq) }
func (pq priorityQueue) Less(i, j int) bool {
	return bytes.Compare(pq[i].key, pq[j].key) < 0
}
func (pq priorityQueue) Swap(i, j int) {
	pq[i], pq[j] = pq[j], pq[i]
	pq[i].index = i
	pq[j].index = j
}
func (pq *priorityQueue) Push(x interface{}) {
	n := len(*pq)
	item := x.(*heapItem)
	item.index = n
	*pq = append(*pq, item)
}
func (pq *priorityQueue) Pop() interface{} {
	old := *pq
	n := len(old)
	item := old[n-1]
	item.index = -1
	*pq = old[0 : n-1]
	return item
}

type mergeHeapIterator struct {
	pq      priorityQueue
	lastKey []byte
	err     error
}

func newMergeHeapIterator(iters []kvIterator) (*mergeHeapIterator, error) {
	mh := &mergeHeapIterator{
		pq: make(priorityQueue, 0, len(iters)),
	}
	for _, it := range iters {
		k, v, ok, err := it.Next() // Первый элемент каждого итератора
		if err != nil { return nil, err }
		if ok {
			heap.Push(&mh.pq, &heapItem{iter: it, key: k, value: v})
		}
	}
	return mh, nil
}

func (m *mergeHeapIterator) Next() ([]byte, []byte, bool, error) {
	if m.err != nil { return nil, nil, false, m.err }
	for m.pq.Len() > 0 {
		item := heap.Pop(&m.pq).(*heapItem) // Минимальный ключ

		// Продвигаем итератор, из которого был взят элемент
		k, v, ok, err := item.iter.Next()
		if err != nil { m.err = err; return nil, nil, false, err }
		if ok {
			heap.Push(&m.pq, &heapItem{iter: item.iter, key: k, value: v})
		}

		// Tombstone – запоминаем ключ и пропускаем
		if item.value == nil {
			m.lastKey = append([]byte(nil), item.key...)
			continue
		}
		// Дубликат (уже выдавали более новую версию)
		if m.lastKey != nil && bytes.Equal(item.key, m.lastKey) {
			continue
		}
		m.lastKey = append([]byte(nil), item.key...)
		return item.key, item.value, true, nil
	}
	return nil, nil, false, nil
}

func (m *mergeHeapIterator) Close() error {
	// Итераторы будут закрыты вызывающей стороной, здесь ничего не делаем
	return nil
}